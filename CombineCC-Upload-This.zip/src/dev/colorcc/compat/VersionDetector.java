package dev.colorcc.compat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;

/** Samsung-specific One UI detection; SDK alone is never sufficient. */
public final class VersionDetector {
    public enum Family { ONE_UI_8, ONE_UI_9, UNSUPPORTED }

    public static final class Result {
        public final Family family;
        public final int oneUiCode;
        public final int sdk;
        public final String manufacturer;
        public final String detail;

        Result(Family family, int oneUiCode, int sdk, String manufacturer, String detail) {
            this.family = family;
            this.oneUiCode = oneUiCode;
            this.sdk = sdk;
            this.manufacturer = manufacturer;
            this.detail = detail;
        }
    }

    private VersionDetector() { }

    public static Result detect() {
        String maker = readBuildField("MANUFACTURER");
        int sdk = readIntBuildVersion("SDK_INT");
        int oneUiCode = systemPropertyInt("ro.build.version.oneui", -1);
        return classify(maker, sdk, oneUiCode);
    }

    /** Pure function for unit tests and to avoid guessing on unknown Samsung builds. */
    public static Result classify(String maker, int sdk, int code) {
        String normalized = maker == null ? "" : maker.toLowerCase(Locale.ROOT);
        if (!normalized.equals("samsung")) {
            return new Result(Family.UNSUPPORTED, code, sdk, normalized,
                    "Not a confirmed Samsung device");
        }
        int major = code / 10000;
        if (code < 0 || major < 8 || major > 9) {
            return new Result(Family.UNSUPPORTED, code, sdk, normalized,
                    "Unknown or unsupported Samsung One UI property");
        }
        if (major == 8 && code < 80100 && sdk == 36) {
            return new Result(Family.ONE_UI_8, code, sdk, normalized,
                    "One UI 8.0 property on Android 16; hook probes still required");
        }
        if (major == 9 && code < 90100 && sdk == 37) {
            return new Result(Family.ONE_UI_9, code, sdk, normalized,
                    "One UI 9.0 property on Android 17; hook probes still required");
        }
        return new Result(Family.UNSUPPORTED, code, sdk, normalized,
                "Samsung One UI property and Android SDK are inconsistent");
    }

    private static int systemPropertyInt(String key, int fallback) {
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            Method method = c.getDeclaredMethod("getInt", String.class, int.class);
            method.setAccessible(true);
            return (Integer) method.invoke(null, key, fallback);
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    private static String readBuildField(String name) {
        try {
            Field f = Class.forName("android.os.Build").getField(name);
            return String.valueOf(f.get(null));
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static int readIntBuildVersion(String name) {
        try {
            Field f = Class.forName("android.os.Build$VERSION").getField(name);
            return f.getInt(null);
        } catch (Throwable ignored) {
            return -1;
        }
    }
}
