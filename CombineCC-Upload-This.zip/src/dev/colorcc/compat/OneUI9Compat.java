package dev.colorcc.compat;

/** Android 17 / Samsung One UI 9-family: candidate mapping from the original APK. */
public final class OneUI9Compat {
    public void install(HookResolver resolver) {
        CommonHooks.core(resolver, false);
        CommonHooks.optionalForNine(resolver);
        resolver.log("One UI 9 family: optional targets probed; on-device verification required");
    }
}
