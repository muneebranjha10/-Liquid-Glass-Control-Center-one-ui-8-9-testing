package dev.colorcc.compat;

import java.util.concurrent.atomic.AtomicBoolean;

/** Entry point for a one-method redirect of the ORIGINAL dev.colorcc.Hook.install. */
public final class CompatManager {
    private static final AtomicBoolean INSTALLED = new AtomicBoolean(false);

    private CompatManager() { }

    public static void install(ClassLoader systemUiClassLoader) {
        HookResolver r = new HookResolver(systemUiClassLoader);
        VersionDetector.Result v = VersionDetector.detect();
        r.log("manufacturer=" + v.manufacturer + ", oneui=" + v.oneUiCode
                + ", sdk=" + v.sdk + ", path=" + v.family + "; " + v.detail);
        if (v.family == VersionDetector.Family.UNSUPPORTED) {
            r.log("Unsupported device or inconsistent version: leaving stock SystemUI alone");
            return;
        }
        if (!INSTALLED.compareAndSet(false, true)) {
            r.log("Duplicate initialization suppressed");
            return;
        }
        try {
            if (v.family == VersionDetector.Family.ONE_UI_8) {
                new OneUI8Compat().install(r);
            } else {
                new OneUI9Compat().install(r);
            }
            r.log("Selected " + v.family + ", successful member hooks=" + r.installedCount());
        } catch (Throwable failure) {
            // All hook registrations are individually guarded. We still contain unexpected errors.
            r.log("Unexpected compatibility startup error: " + failure);
        }
    }
}
