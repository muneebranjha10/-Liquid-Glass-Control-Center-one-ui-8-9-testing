package dev.colorcc.compat;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

/**
 * Resolve targets against the actual loaded SystemUI bytecode.
 * A missing or changed method must not bring down SystemUI at startup.
 * Keep this in module code; never package Xposed stub classes in the APK.
 */
public final class HookResolver {
    private final ClassLoader systemLoader;
    private final Set<String> attached = Collections.synchronizedSet(new HashSet<String>());
    private final Map<Integer, XC_MethodHook> originalCallbacks = new HashMap<Integer, XC_MethodHook>();
    private int installedCount;

    public HookResolver(ClassLoader systemLoader) {
        if (systemLoader == null) throw new IllegalArgumentException("SystemUI class loader is null");
        this.systemLoader = systemLoader;
    }

    public void log(String message) {
        try { XposedBridge.log("CombineCC compatibility: " + message); }
        catch (Throwable ignored) { /* Logging is optional; never crash SystemUI for logging. */ }
    }

    public Class<?> find(String className) {
        try { return Class.forName(className, false, systemLoader); }
        catch (Throwable failure) { log("Missing class " + className + " [" + failure.getClass().getSimpleName() + "]"); return null; }
    }

    /** Existing compiled Hook$N callbacks are reused verbatim, not reimplemented. */
    public synchronized XC_MethodHook callback(int ordinal) {
        XC_MethodHook existing = originalCallbacks.get(ordinal);
        if (existing != null) return existing;
        try {
            Class<?> cls = Class.forName("dev.colorcc.Hook$" + ordinal, false,
                    HookResolver.class.getClassLoader());
            Constructor<?> ctor = cls.getDeclaredConstructor();
            ctor.setAccessible(true);
            XC_MethodHook created = (XC_MethodHook) ctor.newInstance();
            originalCallbacks.put(ordinal, created);
            return created;
        } catch (Throwable failure) {
            log("Missing original callback Hook$" + ordinal + ": " + failure);
            return null;
        }
    }

    public boolean constructor(String className, int callbackNumber) {
        Class<?> cls = find(className);
        XC_MethodHook hook = callback(callbackNumber);
        if (cls == null || hook == null) return false;
        Constructor<?>[] constructors;
        try { constructors = cls.getDeclaredConstructors(); }
        catch (Throwable t) { log("Cannot inspect constructors " + className); return false; }
        int ok = 0;
        for (Constructor<?> c : constructors) {
            if (attach(c, hook, callbackNumber)) ok++;
        }
        if (ok == 0) log("No compatible constructor: " + className);
        return ok > 0;
    }

    /** Hooks all existing overloads, retaining original hookAllMethods semantics. */
    public boolean method(String className, String methodName, int callbackNumber) {
        return method(className, methodName, callbackNumber, (String[]) null);
    }

    /**
     * Constrain a high-risk hook by its EXACT parameter descriptor (e.g. "float", "boolean").
     * Null paramNames means inspect & hook each declared overload; empty array means zero args.
     */
    public boolean method(String className, String methodName, int callbackNumber,
                          String... paramNames) {
        Class<?> cls = find(className);
        XC_MethodHook hook = callback(callbackNumber);
        if (cls == null || hook == null) return false;
        int ok = 0;
        try {
            for (Method method : cls.getDeclaredMethods()) {
                if (!method.getName().equals(methodName) || Modifier.isAbstract(method.getModifiers())) continue;
                if (paramNames != null && !sameParameters(method, paramNames)) continue;
                if (attach(method, hook, callbackNumber)) ok++;
            }
        } catch (Throwable failure) {
            log("Inspection failed " + className + "#" + methodName + ": " + failure);
        }
        if (ok == 0) log("No compatible method " + className + "#" + methodName);
        return ok > 0;
    }

    private boolean attach(Member member, XC_MethodHook callback, int number) {
        String id = member.toString();
        if (!attached.add(id)) {
            log("Duplicate hook skipped: " + id);
            return false;
        }
        try {
            XposedBridge.hookMethod(member, callback);
            installedCount++;
            return true;
        } catch (Throwable failure) {
            attached.remove(id);
            log("Hook failed " + id + " (Hook$" + number + "): " + failure);
            return false;
        }
    }

    private static boolean sameParameters(Method method, String[] expected) {
        Class<?>[] actual = method.getParameterTypes();
        if (actual.length != expected.length) return false;
        for (int i = 0; i < actual.length; i++) {
            if (!actual[i].getName().equals(expected[i])) return false;
        }
        return true;
    }

    public int installedCount() { return installedCount; }
}
