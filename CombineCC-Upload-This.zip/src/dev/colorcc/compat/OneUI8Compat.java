package dev.colorcc.compat;

/** Android 16 / Samsung One UI 8-family: verified presence, not runtime verified. */
public final class OneUI8Compat {
    public void install(HookResolver resolver) {
        // The baseline methods below were checked against the user-supplied Android 16 APK.
        // Still guarded individually because OEM builds and subrevisions can differ.
        CommonHooks.core(resolver, true);
        resolver.log("One UI 8 family: skipping unverified/missing synthetic/detail hooks");
    }
}
