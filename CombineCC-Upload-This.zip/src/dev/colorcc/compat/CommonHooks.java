package dev.colorcc.compat;

/**
 * Hook mapping recovered from the uploaded Combine CC classes.dex.
 * Callback numbers are the EXISTING original Hook$1 .. Hook$24 classes.
 * No renderer, motion math, settings store, or panel view is replaced here.
 */
final class CommonHooks {
    private static final String SYS = "com.android.systemui.";
    private static final String SHADE = SYS + "shade.";
    private static final String QS = SYS + "qs.";
    private static final String SAMSUNG_QS = SYS + "samsung.quicksetting.";
    private static final String BLUR = SYS + "blur.";

    private CommonHooks() { }

    static void core(HookResolver r, boolean strictOneUi8) {
        // Crash reporter path from original Hook.install. Best-effort: Android versions vary.
        r.method("java.lang.Thread", "dispatchUncaughtException", 1,
                 "java.lang.Throwable");

        // Capture stock tiles / panel context and replace with original ColorCC panel.
        r.constructor(QS + "QSHostAdapter", 2);
        r.constructor(SAMSUNG_QS + "SecQSPanelComposeAdapter", 3);
        r.constructor(QS + "QSContainerImpl", 4);

        // Original opening / closing and shade gestures.
        if (strictOneUi8) {
            r.method(QS + "animator.PanelTransitionAnimator", "slide", 5,
                     "float", "float", SHADE + "PanelSlideEventHandler$Direction", "int");
        } else {
            // The ORIGINAL One UI 9 module hooks all slide overloads.
            r.method(QS + "animator.PanelTransitionAnimator", "slide", 5);
        }
        r.method(SHADE + "PanelSlideEventHandler", "createSlideAnimatorAndRun", 6,
                 "float", "float");
        if (strictOneUi8) {
            r.method(SHADE + "SecPanelSplitHelper", "onPanelExpansionChanged", 7,
                     SHADE + "ShadeExpansionChangeEvent");
        } else {
            r.method(SHADE + "SecPanelSplitHelper", "onPanelExpansionChanged", 7);
        }

        // Original detail-panel dismissal pathways. Only installed if present.
        r.method(QS + "QSFragmentLegacy", "closeDetail", 8);
        r.method(QS + "composefragment.QSFragmentCompose", "closeDetail", 8);
        r.method(QS + "SecQSDetailController", "closeDetail", 8);
        r.method(QS + "QSImpl", "closeDetail", 8);
        r.method(SYS + "back.domain.interactor.BackActionInteractor", "onBackRequested", 9);
        r.constructor(SAMSUNG_QS + "ui.panel.QuickSettingSceneViewModel", 10);

        // Touch/gesture correction from ORIGINAL Hook$15.
        r.method(SHADE + "SecPanelSplitHelper", "onIntercept", 15);
        r.method(SHADE + "SecPanelSplitHelper", "handleTouch", 15);

        // Backdrop, blur and frame-independent motion callbacks from the original module.
        r.method(BLUR + "QSColorCurve", "setFraction", 16, "float");
        r.method(BLUR + "domain.interactor.SecCapturedBlurBitmapGenerator",
                 "getBlurredBitmapWithEffect", 17);
        r.method("com.samsung.android.view.SemWindowManager", "screenshot", 18);
        r.method(SHADE + "NotificationPanelViewController", "setOverExpansionInternal", 19,
                 "float", "boolean");
        r.method(SHADE + "NotificationPanelViewController", "flingToHeight", 20,
                 "float", "boolean", "float", "float", "boolean");
        r.method(BLUR + "ui.viewbinder.SecPanelWindowBlurBinder", "doBlur", 21);
        r.method(BLUR + "domain.interactor.SecPanelWindowBlurInteractor",
                 "getSemBlurInfoBuilder", 22, "int");
        r.method(SYS + "statusbar.NotificationShadeDepthController",
                 "computeBlurAndZoomOut", 23);
        r.method(QS + "QSContainerImpl", "onFinishInflate", 24);
    }

    static void optionalForNine(HookResolver r) {
        // These targets are absent in the supplied Android 16 SystemUI DEX or
        // have different signatures. Discover each independently on One UI 9.
        // Original Hook$8 is shared among closeDetail, legacy visibility and done paths.
        r.method(SAMSUNG_QS + "SecQSPanelComposeAdapter",
                 "setLegacyDetailVisible", 8, "boolean");
        r.method(SAMSUNG_QS + "ui.details.DetailViewModel", "onDoneClicked", 8);
        r.method(SAMSUNG_QS + "ui.details.screenprivacy.ScreenPrivacyDetailViewModel",
                 "onDoneClicked", 8);
        r.method(SAMSUNG_QS + "ui.panel.QuickSettingSceneViewModel",
                 "setDetailVisible", 11, "boolean");
        r.method(SHADE + "SecPanelSplitHelper", "isInNonCollapsibleArea", 12);
        r.method(SHADE + "SecPanelSplitHelper", "isInCollapsibleArea", 13);
        r.method(SAMSUNG_QS + "ui.panel.QuickSettingTileGridKt$QuickSettingTileGrid$4$1$2",
                 "emit", 14);
    }
}
