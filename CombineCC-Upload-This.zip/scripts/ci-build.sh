#!/usr/bin/env bash
set -euo pipefail

# This is an UNTESTED compatibility candidate; a successful build is not device verification.
BASE='input/Combine-CC-Geometry-Experimental.apk'
test -s "$BASE"
echo 'd731fb16db3fee293148731fee962a49432c484dfc5490fea9c8ac94bcd8694c  input/Combine-CC-Geometry-Experimental.apk' | sha256sum -c -
unzip -t "$BASE" >/dev/null
test "$(unzip -p "$BASE" assets/xposed_init)" = 'dev.colorcc.Hook'

curl --fail --location --retry 3 -o apktool.jar 'https://github.com/iBotPeaches/Apktool/releases/download/v3.0.3/apktool_3.0.3.jar'
echo 'dbf930b076c6b9be08d57c449cacefc3bdd6b71ebd59b3066fc0e1f5b14f9423  apktool.jar' | sha256sum -c -
java -jar apktool.jar d -f -r "$BASE" -o build/decoded
python3 build-support/patch_smali.py --decoded build/decoded
java -jar apktool.jar b build/decoded -o build/base-unsigned.apk

mkdir -p build/compiled build/dex dist
find src build-support/stubs tests -name '*.java' -print0 | xargs -0 javac --release 8 -encoding UTF-8 -d build/compiled
java -cp build/compiled VersionDetectorTest
jar cf build/compat.jar -C build/compiled dev/colorcc/compat
TOOL="$ANDROID_HOME/build-tools/36.0.0"
"$TOOL/d8" --min-api 33 --lib "$ANDROID_HOME/platforms/android-36/android.jar" --output build/dex build/compat.jar
cp build/dex/classes.dex build/classes2.dex
! jar tf build/compat.jar | grep '^de/robv/android/xposed/'
cp build/base-unsigned.apk build/module-unsigned.apk
(cd build && zip -q -9 module-unsigned.apk classes2.dex)
unzip -t build/module-unsigned.apk >/dev/null
test "$(unzip -Z1 build/module-unsigned.apk | grep -c '^classes[0-9]*.dex$')" -eq 2
"$TOOL/zipalign" -p -f 4 build/module-unsigned.apk build/aligned.apk
"$TOOL/zipalign" -c -p 4 build/aligned.apk

if [[ -n "${CC_KEYSTORE_BASE64:-}" ]]; then
  test -n "${CC_KEY_ALIAS:-}" && test -n "${CC_KEYSTORE_PASS:-}" && test -n "${CC_KEY_PASS:-}"
  printf '%s' "$CC_KEYSTORE_BASE64" | base64 -d > build/signing.jks
  alias_name="$CC_KEY_ALIAS"; store_pass="$CC_KEYSTORE_PASS"; key_pass="$CC_KEY_PASS"
else
  keytool -genkeypair -noprompt -keystore build/signing.jks -alias test -storepass android -keypass android -keyalg RSA -keysize 3072 -validity 3650 -dname 'CN=CombineCC OneUI8-9 TEST ONLY'
  alias_name=test; store_pass=android; key_pass=android
fi
"$TOOL/apksigner" sign --ks build/signing.jks --ks-key-alias "$alias_name" --ks-pass "pass:$store_pass" --key-pass "pass:$key_pass" --out dist/CombineCC-OneUI8-9-UNTESTED.apk build/aligned.apk
"$TOOL/apksigner" verify --verbose --print-certs dist/CombineCC-OneUI8-9-UNTESTED.apk
unzip -t dist/CombineCC-OneUI8-9-UNTESTED.apk >/dev/null
sha256sum dist/CombineCC-OneUI8-9-UNTESTED.apk
