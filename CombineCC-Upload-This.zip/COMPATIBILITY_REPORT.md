# Combine CC One UI 8 + One UI 9 — Compatibility audit and candidate patch

**Status:** Java source compiled and version-classifier unit tests passed locally. **No amended APK built or on-device testing done.** This is a conditional integration package, *not* a certified dual-OneUI release.

## Evidence
- Supplied base: `Combine-CC-Geometry-Experimental (1).apk`, SHA-256 `d731fb16db3fee293148731fee962a49432c484dfc5490fea9c8ac94bcd8694c`, valid ZIP; 1 DEX (372,752 bytes uncompressed).
- Package: `dev.colorcc`, version `0.99.58` (157), min SDK 33, target SDK 36, **xposedmodule=true**, entry: `assets/xposed_init = dev.colorcc.Hook`, scope resource contains `com.android.systemui`.
- Original compiled classes include `dev.colorcc.Hook`, `Panel`, `Glass`, `GpuBlur`, `Motion`, `PageSwipe`, `SideSlide`, `SpringStep`, `Logic`, `Slider`; original Hook$1..Hook$24 anonymous callback classes exist with no-arg constructors.
- Supplied comparison: `System UI.apk`, SHA-256 `6ca6fa7659835cfa049932bf7652b6ab5fdb6d1c812e2c0139038d8b98f0a048`, package `com.android.systemui`, Android version 16, min/target SDK 36, four DEX files. These facts are consistent with a One UI 8-family build **but do not identify the Samsung One UI property or exact firmware**.
- NO matching One UI 9 SystemUI APK or original editable Gradle project provided. The existing GitHub `muneebranjha10/Cc` is a binary-patching pipeline, not original ColorCC source.

## Hook matrix (runtime verification is NONE for both)

| Original hook target | Supplied Android 16 class/method result | One UI 8 candidate | One UI 9 candidate |
|---|---|---|---|
| QSHostAdapter constructor | Found | Guarded existing Hook$2 | Guarded existing Hook$2, unverified target |
| SecQSPanelComposeAdapter constructor | Found | Guarded existing Hook$3 | Guarded existing Hook$3, unverified target |
| QSContainerImpl constructor / onFinishInflate | Both found | Guarded Hook$4/$24 | Guarded Hook$4/$24, unverified target |
| PanelTransitionAnimator.slide(float,float,Direction,int) | Found | Exact signature, Hook$5 | Probe target, Hook$5 |
| PanelSlideEventHandler.createSlideAnimatorAndRun(float,float) | Found | Exact signature, Hook$6 | Probe target, Hook$6 |
| SecPanelSplitHelper.onPanelExpansionChanged(ShadeExpansionChangeEvent) | Found | Exact signature, Hook$7 | Probe target, Hook$7 |
| QSFragmentLegacy, QSImpl, QSFragmentCompose, SecQSDetailController closeDetail | Present | Guarded Hook$8 | Guarded Hook$8 |
| BackActionInteractor.onBackRequested | Found | Guarded Hook$9 | Guarded Hook$9 |
| QuickSettingSceneViewModel constructor | Found | Guarded Hook$10 | Guarded Hook$10 |
| QuickSettingSceneViewModel.setDetailVisible | **Not declared** | Skip | Probe, optional Hook$11 |
| SecPanelSplitHelper.isInNonCollapsibleArea | **Not declared** | Skip | Probe, optional Hook$12 |
| SecPanelSplitHelper.isInCollapsibleArea | **Not declared** | Skip | Probe, optional Hook$13 |
| QuickSettingTileGridKt$QuickSettingTileGrid$4$1$2.emit | **Class absent** | Skip | Probe, optional Hook$14 |
| SecPanelSplitHelper.onIntercept / handleTouch | Both found | Guarded Hook$15 | Guarded Hook$15 |
| QSColorCurve.setFraction(float) | Found | Guarded Hook$16 | Guarded Hook$16 |
| SecCapturedBlurBitmapGenerator.getBlurredBitmapWithEffect | Found | Guarded Hook$17 | Guarded Hook$17 |
| SemWindowManager.screenshot | Not in SystemUI DEX (framework class may be provided separately) | Probe, optional Hook$18 | Probe, optional Hook$18 |
| NotificationPanelViewController.setOverExpansionInternal(float,boolean) | Found | Exact signature, Hook$19 | Probe, Hook$19 |
| NotificationPanelViewController.flingToHeight(float,boolean,float,float,boolean) | Found | Exact signature, Hook$20 | Probe, Hook$20 |
| SecPanelWindowBlurBinder.doBlur | Found | Guarded Hook$21 | Guarded Hook$21 |
| SecPanelWindowBlurInteractor.getSemBlurInfoBuilder(int) | Found | Guarded Hook$22 | Guarded Hook$22 |
| NotificationShadeDepthController.computeBlurAndZoomOut | Found | Guarded Hook$23 | Guarded Hook$23 |

**Method existence is not behavioral compatibility.** View trees, invoked args, Samsung variants, frame pacing, GPU shader correctness, and original callback assumptions are still unverified. In particular, hooking a compatible signature does not establish that its callback is safe.

## What this candidate attempts
- The original `dev.colorcc.Hook.handleLoadPackage` remains intact, including its repeated-crash protection. Each original callback is cached per ordinal, preserving reuse of Hook$8 and Hook$15 across multiple targets.
- Only the `Hook.install(ClassLoader)` body is replaced to route registrations through `CompatManager`.
- It adds `classes2.dex` containing guarded registrations. Existing compiled Hook$1..Hook$24 callback implementations, original `Panel`, shaders, tiles, icons, blur and animation logic are **not rewritten**.
- At runtime it reads Samsung's `ro.build.version.oneui` with reflection and checks manufacturer plus SDK (8.0 + API 36; 9.0 + API 37), not SDK alone.
- Unsupported, inconsistent or unrecognized version properties cause the module to leave stock SystemUI alone.
- Missing hook targets are logged and skipped; duplicate member hooks are guarded.
- One UI 8 skips the four listed missing optional paths, rather than inventing replacement APIs.

## Identified source limitation
The input APK has **no Activity declared in its manifest**. This is a SystemUI-hosted module with an in-panel editor, not a standalone configuration application with a launchable **Apply** or **Soft Restart** button. Its `Panel$Body.apply()` is a compiled layout method, not evidence of an Apply UI action. Therefore this package cannot honestly claim to implement or test the requested standalone Apply / Soft Restart feature. An actual source project that contains those controls is needed to wire them without changing the product UX.

## Unresolved technical and safety concerns
1. **One UI 9 bytecode comparison:** no One UI 9 SystemUI sample provided; every One UI 9 mapping requires discovery and on-device testing.
2. **Preservation:** callbacks are reused as-is, but replacing original registration code could omit optional detail-close paths. The candidate cannot be called feature-complete until parity tests pass.
3. **Binary rebuild:** APKTool decoding/assembly, D8 multidex injection, zipalign, apksigner and install were not executable in the present environment; CI workflow was authored but **not run**.
4. **Certificate:** original app signing key is unavailable; a newly signed APK cannot replace another signing certificate for `dev.colorcc` without uninstalling the old install. Keep a settings backup.
5. **Performance:** there is no frame-time measurement or device trace. Registration guards alone do not prove 60/120 FPS or smooth closing gestures.
6. **One UI 8.5 and future versions:** intentionally excluded until inspected. Never infer from Android 16 alone.
7. **Subtle failure mode:** inherited/overridden reflective methods and method overloads can differ; a matching name doesn't prove the original callback's assumptions about args, view classes and global state.

## Required real-device test matrix

| Test | One UI 8 / Android 16 | One UI 9 / Android 17 |
|---|---|---|
| LSPosed recognizes entry + correct SystemUI scope | Not tested | Not tested |
| `CompatManager` detects actual Samsung property | Not tested | Not tested |
| Hook registration and callback execution | Not tested | Not tested |
| Stock panel replaced without crash | Not tested | Not tested |
| Every tile / brightness / volume / edit UI works | Not tested | Not tested |
| Open, close, slow drag, reverse mid-gesture | Not tested | Not tested |
| GPU blur / liquid glass / shader compilation | Not tested | Not tested |
| Dark mode, split panel, rotation, lock screen | Not tested | Not tested |
| Real frame-times at 60 and 120 Hz | Not tested | Not tested |
| Persistence across SystemUI restart | Not tested | Not tested |
| Apply and root-authorized soft restart | No independent UI in supplied APK | No independent UI in supplied APK |
| SystemUI stability and rollback | Not tested | Not tested |

**Do not flash/replace SystemUI.apk.** It is reference material only. On a test phone, back up data, install only the signed module, enable LSPosed scope for SystemUI, test after a controlled SystemUI restart; keep a recovery route to disable the module. If the panel stops functioning or SystemUI crashes, disable the module and restore the known-good APK.
