package de.robv.android.xposed;
/** Compile-only stub: DO NOT include in final APK. */
public abstract class XC_MethodHook { public static class Unhook { } }
