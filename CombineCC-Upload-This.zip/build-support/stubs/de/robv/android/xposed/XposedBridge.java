package de.robv.android.xposed;
import java.lang.reflect.Member;
/** Compile-only stub: DO NOT include in final APK. */
public final class XposedBridge {
    public static void log(String message) { }
    public static XC_MethodHook.Unhook hookMethod(Member method, XC_MethodHook callback) { return null; }
}
