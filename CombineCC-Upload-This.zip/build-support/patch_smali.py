#!/usr/bin/env python3
"""Replace exactly one registration method, preserving all original callbacks/rendering code.
Requires APKTool to have decoded the user's own APK. Fails closed on unexpected layout.
"""
import argparse
import pathlib
import re
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--decoded', required=True)
args = parser.parse_args()
base = pathlib.Path(args.decoded)
candidates = list(base.glob('smali*/dev/colorcc/Hook.smali'))
if len(candidates) != 1:
    raise SystemExit(f'Expected exactly one Hook.smali; found {len(candidates)}')
p = candidates[0]
src = p.read_text()
pattern = re.compile(r'(?ms)^\.method private static install\(Ljava/lang/ClassLoader;\)V\n.*?^\.end method\s*')
replacement = '''\
.method private static install(Ljava/lang/ClassLoader;)V
    .locals 0
    # Original visuals/callbacks are preserved; guarded hooks selected by Samsung One UI.
    invoke-static {p0}, Ldev/colorcc/compat/CompatManager;->install(Ljava/lang/ClassLoader;)V
    return-void
.end method

'''
new, count = pattern.subn(replacement, src)
if count != 1:
    raise SystemExit(f'Expected one exact original install() method, found {count}; not patching')
assert 'Ldev/colorcc/Hook$24;' in src
assert 'Ldev/colorcc/Hook$1;' in src
p.write_text(new)
print('Patched one original hook installer in', p)
