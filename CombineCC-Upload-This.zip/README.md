# Combine CC — One UI 8 + One UI 9 compatibility patch (SOURCE-ONLY CANDIDATE)

**No APK has been built or verified from this package.** It is not a replacement for the original editable source project. Use only with permission to modify the base module.

The supplied APK is a compiled LSPosed module and does not contain the original Gradle source. Instead of replacing its animations, the patch workflow decompiles it and keeps the original `Panel`, GPU renderer, `Hook$1`–`Hook$24` callbacks and entry-point class while replacing the central hook registration method with a new version dispatcher. This is a risky experimental candidate until CI build and phone tests succeed.

## Files
- `src/dev/colorcc/compat/`: Java compatibility adapter, hook resolver, OneUI8Compat, OneUI9Compat, runtime Samsung version detector.
- `build-support/patch_smali.py`: fail-closed one-method APKTool patch to the original `Hook.install`.
- `build-support/stubs/`: compile-only Xposed API stubs; NEVER pack them inside APK.
- `.github/workflows/build-dual-oneui.yml`: APKTool + D8 + zipalign + apksigner CI candidate pipeline.
- `COMPATIBILITY_REPORT.md`: exact hook availability and incomplete tests.

## Build from your Android phone using GitHub Actions

1. Create or use a **private** GitHub repository for this workflow; do not publish the third-party base APK in a public repository.
2. Upload this patch source tree to that private repo, preserving `.github/workflows/build-dual-oneui.yml`.
3. Upload YOUR original `Combine-CC-Geometry-Experimental (1).apk` as `input/Combine-CC-Geometry-Experimental.apk` (the workflow refuses any other SHA-256).
4. Open GitHub → repository → **Actions** → **Build CombineCC dual-OneUI candidate (UNTESTED)** → **Run workflow**.
5. If and only if the workflow succeeds, download and extract the `CombineCC-OneUI8-9-UNTESTED` artifact. Inspect the logs; signed/verified doesn't mean compatible.
6. Before installing, **back up your original APK and module settings**. If the new signing certificate differs, Android may require uninstalling the old app. That can remove local app data. A stable signing keystore is recommended via GitHub Actions secrets: `CC_KEYSTORE_BASE64`, `CC_KEY_ALIAS`, `CC_KEYSTORE_PASS`, `CC_KEY_PASS`.
7. Enable the installed module in LSPosed Manager, scope only `com.android.systemui`, restart SystemUI with your authorized root tooling, then inspect LSPosed logs and test the checklist in the compatibility report.

## Expected console-only compiler self-test

```bash
mkdir -p /tmp/cc-classes
javac --release 8 -d /tmp/cc-classes $(find src build-support/stubs tests -name '*.java')
java -cp /tmp/cc-classes VersionDetectorTest
# PASS: 7 Samsung-version classification cases
```

**Not implemented:** this APK does not contain a launchable Android Activity, nor a confirmed standalone Apply/Soft Restart UI to attach the requested buttons to. The supplied SystemUI binary is consistent with Android 16; an Android 17 / One UI 9 SystemUI.apk and real-device logs are needed to substantiate dual-version support.
