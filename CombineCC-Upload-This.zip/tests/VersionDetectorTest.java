import dev.colorcc.compat.VersionDetector;
import dev.colorcc.compat.VersionDetector.Family;

public class VersionDetectorTest {
    private static void require(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        require(VersionDetector.classify("samsung", 36, 80000).family == Family.ONE_UI_8, "One UI 8.0");
        require(VersionDetector.classify("SAMSUNG", 36, 80500).family == Family.UNSUPPORTED, "One UI 8.5 unverified");
        require(VersionDetector.classify("samsung", 37, 90000).family == Family.ONE_UI_9, "One UI 9.0");
        require(VersionDetector.classify("samsung", 36, 90000).family == Family.UNSUPPORTED, "SDK mismatch");
        require(VersionDetector.classify("samsung", 37, -1).family == Family.UNSUPPORTED, "missing oneui property");
        require(VersionDetector.classify("Google", 37, 90000).family == Family.UNSUPPORTED, "other vendor");
        require(VersionDetector.classify("samsung", 37, 100000).family == Family.UNSUPPORTED, "newer unvalidated version");
        System.out.println("PASS: 7 Samsung-version classification cases");
    }
}
